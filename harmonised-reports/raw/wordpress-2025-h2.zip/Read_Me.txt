﻿WordPress.com DMCA_Requests_Jul-Dec_2025.csv


This file contains details on DMCA complaints for July through December 2025.
See https://transparency.automattic.com/wordpress-dot-com/intellectual-property/ for more information on Trademark and DMCA reports.








WordPress.com Government_Information_Requests_Jul-Dec_2025.csv


This file contains details on Government Information Requests for July through December 2025. 
See https://transparency.automattic.com/wordpress-dot-com/government-information-requests/ for more information.








WordPress.com Government_Removal_Requests_Jul-Dec_2025.csv


This file contains details on Government Removal Requests for July through December 2025. 
See https://transparency.automattic.com/wordpress-dot-com/government-takedown-demands/ for more information.








WordPress.com Trademark_Reports_Jul-Dec_2025.csv


This file contains details on Trademark complaints for July through December 2025.
See https://transparency.automattic.com/wordpress-dot-com/intellectual-property/ for more information on Trademark and DMCA reports.








WordPress.com IRU_Reports_Jul-Dec_2025.csv


This file contains details IRU requests for July through December 2025. 
See https://transparency.automattic.com/wordpress-dot-com/iru-reports/ for more information.